<?php 


//$conn = mysqli_connect('localhost','pimmsedu_soft_acu','3vJp-mN&.=H8','pimmsedu_soft_ac2') or die('database down');

 ?>
 
<?php 
 

$conn = mysqli_connect('localhost','pimmsedu_lenovo','Lenovo900@') or die('server down');
mysqli_select_db($conn,'pimmsedu_pims_fee') or die('Database error');

 ?>