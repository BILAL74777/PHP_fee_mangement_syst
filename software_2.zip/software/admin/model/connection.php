<?php 
 
$conn = mysqli_connect('localhost','pimmsedu_lenovo','Lenovo900@') or die('server down');
mysqli_select_db($conn,'pimmsedu_pims_fee') or die('Database error');

 ?>