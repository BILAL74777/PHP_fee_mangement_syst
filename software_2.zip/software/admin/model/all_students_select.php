<?php 

include('connection.php');

$selectAllStudents = mysqli_query($conn,"SELECT * FROM registered_student");


 ?>